// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "QuickFileLauncherModule.h"
#include "FAUtilities.h"
//#include "DesktopPlatformModule.h"
//#include "EditorDirectories.h"
#include "IconStyle.h"
#include "SFavoritesPanel.h"
#include "ToolMenus.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"

#define LOCTEXT_NAMESPACE "FQuickFileLauncherModule"

void FQuickFileLauncherModule::StartupModule()
{
	FIconStyle::InitializeIcons();
	FToolBarIconStyle::Initialize();
	FToolBarIconStyle::ReloadTextures();

	//FileAssistantCommands::Register();
	
	//RegisterToolBarFAMenu();
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FQuickFileLauncherModule::RegisterToolBarFAMenu));
	RegisterIconPanelTab();
}

void FQuickFileLauncherModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);

	//FileAssistantCommands::Unregister();
	
	FIconStyle::ShutDownIcons();
	FToolBarIconStyle::ShutDown();
	
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(FName(FAUtilities::GetQuickFileLauncherName()));
}

void FQuickFileLauncherModule::RegisterToolBarFAMenu()
{
	FToolMenuOwnerScoped OwnerScoped(this);
	
	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	
	FToolMenuSection& Section = ToolbarMenu->FindOrAddSection(FName(FAUtilities::GetQuickFileLauncherName()));
	
	Section.AddEntry(FToolMenuEntry::InitToolBarButton(
		FName(FAUtilities::GetQuickFileLauncherName()),
		FExecuteAction::CreateStatic(&FQuickFileLauncherModule::OpenQuickFileLauncherPanel),
		FText::FromString(FAUtilities::GetQuickFileLauncherName()),
		FText::FromString("Open QuickFileLauncher panel"),
		FSlateIcon(FToolBarIconStyle::GetToolBarStyleSetName(),"IconSet.ToolBarIcon")
		)
	);
}

void FQuickFileLauncherModule::OpenQuickFileLauncherPanel()
{
	FGlobalTabmanager::Get()->TryInvokeTab(FName(FAUtilities::GetQuickFileLauncherName()));
}

void FQuickFileLauncherModule::RegisterIconPanelTab()
{
	FGlobalTabmanager::Get()->RegisterTabSpawner(
		FName(FAUtilities::GetQuickFileLauncherName()),
		FOnSpawnTab::CreateLambda([](const FSpawnTabArgs& SpawnTabArgs)
		{
			TSharedRef<SDockTab> TabPtr = SNew(SDockTab)
			.TabRole(ETabRole::NomadTab)
				[
					SNew(SFavoritesPanel)
				];
			TabPtr->SetTabIcon(FToolBarIconStyle::Get().GetBrush(FName("IconSet.ToolBarIcon")));
			return TabPtr;
		}));
}

/*FQuickFileLauncherModule& FQuickFileLauncherModule::Get()
{
	return FModuleManager::LoadModuleChecked<FQuickFileLauncherModule>(FName(FAUtilities::GetQuickFileLauncherName()));
}*/

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FQuickFileLauncherModule, QuickFileLauncher)