﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

class FFAItem
{
public:
	explicit FFAItem(FString InShortcutPath);

	FString GetShortcutPath() const;

	FString GetBaseName() const;

	FName GetIconName() const;

	FString GetIconPath() const;
	
	/** Get the event fired whenever a rename is requested */
	FSimpleDelegate& OnRenameRequested();

	/** Get the event fired whenever a rename is canceled */
	FSimpleDelegate& OnRenameCanceled();
	
private:
	FString ShortcutPath;

	/*
	 *FString SourceFilePath; /*unsetting#1#
	FString IconPath; /*unsetting#1#
	FString DirectoryPath; /*unsetting#1#
	*/

	/** Broadcasts whenever a rename is requested */
	FSimpleDelegate RenameRequestedEvent;

	/** Broadcasts whenever a rename is canceled */
	FSimpleDelegate RenameCanceledEvent;
};
