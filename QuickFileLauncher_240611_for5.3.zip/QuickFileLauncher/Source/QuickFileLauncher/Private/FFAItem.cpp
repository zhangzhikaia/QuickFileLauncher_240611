﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#include "FFAItem.h"

#include "FAUtilities.h"

FFAItem::FFAItem(FString InShortcutPath)
{
	ShortcutPath = InShortcutPath;
}

FString FFAItem::GetShortcutPath() const
{
	return ShortcutPath;
}

FString FFAItem::GetBaseName() const
{
	return FPaths::GetBaseFilename(ShortcutPath);
}

FName FFAItem::GetIconName() const
{
	return FName(FString("IconSet.") + GetBaseName());
}

FString FFAItem::GetIconPath() const
{
	return FPaths::Combine(FAUtilities::GetIconsDirectory(),GetBaseName() + ".png");
}

FSimpleDelegate& FFAItem::OnRenameRequested()
{
	return RenameRequestedEvent;
}

FSimpleDelegate& FFAItem::OnRenameCanceled()
{
	return RenameCanceledEvent;
}
