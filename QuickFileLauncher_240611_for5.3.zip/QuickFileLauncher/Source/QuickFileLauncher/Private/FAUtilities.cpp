// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FAUtilities.h"
#include "IconStyle.h"

#if PLATFORM_WINDOWS
/*Open file dialog*/
#include "Microsoft/COMPointer.h"
//#include "DesktopPlatformModule.h"
#include <windows.h>  
#include <commdlg.h>  
#include <shobjidl.h>  
//#include <iostream>  
// need link to shlwapi.lib and ole32.lib  
#pragma comment(lib, "shlwapi.lib")  
#pragma comment(lib, "ole32.lib")
/*Open file dialog*/

/*ExtractIcon*/
//#include <windows.h>    //<gdiplus.h><shellapi.h>dependent
#include <gdiplus.h>
#include <shellapi.h>
#pragma comment(lib, "gdiplus.lib")  //GetEncoderClsid()dependent
//using namespace Gdiplus;
/*ExtractIcon*/

/*CreateShortcut*/
#include "Windows/AllowWindowsPlatformTypes.h"
#include <objbase.h>
#include <ShlGuid.h>
#include <ShlObj.h>
#include "Windows/HideWindowsPlatformTypes.h"
/*CreateShortcutEnd*/

namespace FAUtilitiesProperty
{
	static bool GbOpenedDialogPresent = false;
}

/*Saved/FileAssistant/IconSet*/
FString FAUtilities::GetQuickFileLauncherName()
{
	static FString QuickFileLauncherName(TEXT("QuickFileLauncher"));
	return QuickFileLauncherName;
}

FString FAUtilities::GetQuickFileLauncherFolderPath()
{
	IFileManager& FileManager = IFileManager::Get();
	
	const FString AbsoluteProjectSavedDir = FileManager.ConvertToAbsolutePathForExternalAppForRead(*FPaths::ProjectSavedDir());
	const FString QuickFileLauncherPath = FPaths::Combine(AbsoluteProjectSavedDir,GetQuickFileLauncherName());
	
	if(!FPaths::DirectoryExists(QuickFileLauncherPath))
	{
		FileManager.MakeDirectory(*QuickFileLauncherPath);
	}
	return QuickFileLauncherPath;
}

FString FAUtilities::GetIconsDirectory()
{
	const FString IconsFolderPath = FPaths::Combine(GetQuickFileLauncherFolderPath(),TEXT("IconSet"));

	if(!FPaths::DirectoryExists(IconsFolderPath))
	{
		IFileManager::Get().MakeDirectory(*IconsFolderPath);
	}
	return IconsFolderPath;
}

FString FAUtilities::GetShortcutsDirectory()
{
	const FString ShortcutsFolderPath = FPaths::Combine(GetQuickFileLauncherFolderPath(),TEXT("Shortcuts"));
	
	if(!FPaths::DirectoryExists(ShortcutsFolderPath))
	{
		IFileManager::Get().MakeDirectory(*ShortcutsFolderPath);
	}
	return ShortcutsFolderPath;
}

bool FAUtilities::CreateShortcut(const TCHAR* InFilePath)
{
	const FString SavePath = FPaths::Combine(GetShortcutsDirectory(),FPaths::GetBaseFilename(InFilePath) + ".lnk");
	if(FPaths::FileExists(SavePath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
		
	if (!FWindowsPlatformMisc::CoInitialize()) {return false;}
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };
	
	IShellLink* ShellLink = nullptr;
	HRESULT Hresult = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLink, reinterpret_cast<void**>(&ShellLink));
	if (FAILED(Hresult) || !ShellLink) {return false;}
	
	ON_SCOPE_EXIT { SAFE_RELEASE(ShellLink); };

	IPersistFile* PersistFile = nullptr;
	Hresult = ShellLink->QueryInterface(&PersistFile);
	if (FAILED(Hresult) || !PersistFile) {return false;}
	
	ON_SCOPE_EXIT { SAFE_RELEASE(PersistFile); };
	
	ensure(SUCCEEDED(ShellLink->SetPath(InFilePath)));   //source file's full path
	//ensure(SUCCEEDED(ShellLink->SetArguments()));
	//ensure(SUCCEEDED(ShellLink->SetDescription()));  
	//ensure(SUCCEEDED(ShellLink->SetIconLocation()));   
	if (!ensure(SUCCEEDED(PersistFile->Save(*SavePath, true)))) {return false;} //save to full path
	
	if (PersistFile != nullptr) {  PersistFile->Release();  }  
	if (ShellLink != nullptr) {  ShellLink->Release();  }  
	
	CoUninitialize();
	return true;
}

FString FAUtilities::GetShortcutTargetPath(const TCHAR* InFilePath)
{
	FString OutTargetPath = FString();
	
	if (!FWindowsPlatformMisc::CoInitialize()){return OutTargetPath;}
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };
	
	IShellLink* ShellLink = nullptr;
	
	if(SUCCEEDED(::CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLink, reinterpret_cast<void**>(&ShellLink))))
	{
		IPersistFile* PersistFile = nullptr;
		if(SUCCEEDED(ShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<void**>(&PersistFile))))
		{
			
			if(SUCCEEDED(PersistFile->Load(InFilePath, STGM_READ)))
			{
				if(TCHAR TargetPath[MAX_PATH];
					SUCCEEDED(ShellLink->GetPath(TargetPath, MAX_PATH, nullptr, 0)))
				{
					OutTargetPath = TargetPath;
				}
			}
		}
		// Release  
		if (PersistFile != nullptr){  PersistFile->Release();  }  
	}
	if (ShellLink != nullptr){  ShellLink->Release();  }  
	CoUninitialize(); 
	return OutTargetPath;
}

bool FAUtilities::ExtractHIcon(const TCHAR* InFilePath,HICON& InHIcon)
{
	SHFILEINFO Sfi{};  
	
	if (SUCCEEDED(SHGetFileInfo(
		InFilePath,  FILE_ATTRIBUTE_NORMAL,  &Sfi,  sizeof(Sfi),  
		SHGFI_ICON | SHGFI_USEFILEATTRIBUTES | SHGFI_LARGEICON)))
	{
		InHIcon = Sfi.hIcon;
		return true;
	}  
	//ExtractIconEx(filePath, 0, NULL, &hIcon, 1);
	return false;
}

bool FAUtilities::GetEncoderClsid(const TCHAR* Format, CLSID* PClsid)
{
	//using namespace Gdiplus; 
    
	UINT Num = 0;  // number of image encoders  
	UINT Size = 0; // size of the image encoder array in bytes  
  
	Gdiplus::GetImageEncodersSize(&Num, &Size);  
	if(Size == 0) {return false;}
	// Failure  
  
	//Gdiplus::ImageCodecInfo* PImageCodecInfo = (Gdiplus::ImageCodecInfo*)(malloc(Size));
	Gdiplus::ImageCodecInfo* PImageCodecInfo = static_cast<Gdiplus::ImageCodecInfo*>(malloc(Size));
	
	if(PImageCodecInfo == nullptr) return false;  // Failure  
  
	GetImageEncoders(Num, Size, PImageCodecInfo);  
  
	for(UINT j = 0; j < Num; ++j)  
	{  
		if( wcscmp(PImageCodecInfo[j].MimeType, Format) == 0 )  
		{  
			*PClsid = PImageCodecInfo[j].Clsid;  
			free(PImageCodecInfo);
		            
			return true;  // Success  
		}      
	}  
	free(PImageCodecInfo);
   
	return false;  // Not found
}

bool FAUtilities::SaveIconToPng(const TCHAR* InFilePath)
{
	const FString SavePath = FPaths::Combine(GetIconsDirectory(),FPaths::GetBaseFilename(InFilePath) + ".png");
	if(FPaths::FileExists(SavePath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
	
	Gdiplus::GdiplusStartupInput GdiplusStartupInput;  
	ULONG_PTR GdiplusToken;  
	GdiplusStartup(&GdiplusToken, &GdiplusStartupInput, nullptr);

	HICON HIcon = nullptr;
	if(!ExtractHIcon(InFilePath,HIcon))return false;
	if(HIcon == nullptr) return false;
	
	Gdiplus::Bitmap* Bitmap = Gdiplus::Bitmap::FromHICON(HIcon);
	//bitmap->SetResolution(32,32);
	
	if (Bitmap == nullptr) return false;
	
	// save bitmap to PNG
	CLSID PNGClsid;
	if(!GetEncoderClsid(L"image/png", &PNGClsid)) return false;
	Bitmap->Save(*SavePath, &PNGClsid, nullptr);
	
	// clear
	DestroyIcon(HIcon);
	delete Bitmap;
	Bitmap = nullptr;
	Gdiplus::GdiplusShutdown(GdiplusToken);
	
	return true;
}

bool FAUtilities::CopyTexture(const TCHAR* InFilePath)
{
	const FString DestinationPath = FPaths::Combine(GetIconsDirectory(), FPaths::GetBaseFilename(InFilePath)+".png");
	if(FPaths::FileExists(DestinationPath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
	
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

	return PlatformFile.CopyFile(*DestinationPath,InFilePath);
}

bool FAUtilities::OpenFileOrFolder(const TCHAR* InPath)
{
	/*Handling the situation of double-clicking to open, InPath is shortcut path(file)*/
	if(FPaths::FileExists(InPath))
	{
		/*Is the target, whether it's a file or a folder, existing? if existing, open InPath*/
		if(FPaths::FileExists(GetShortcutTargetPath(InPath)) || FPaths::DirectoryExists(GetShortcutTargetPath(InPath)))
		{
			return FWindowsPlatformMisc::OsExecute(TEXT("open"),InPath,nullptr);
		}
		//else 
		return !DeleteMessageDialog(InPath);
	}
	return false;
}

bool FAUtilities::OpenDirectory(const TCHAR* InPath)
{
	/*Handling the case of the open directory , InPath is shortcut path(file)*/
	if(FPaths::FileExists(InPath))
	{
		if(const FString TargetPath = GetShortcutTargetPath(InPath);
			FPaths::FileExists(TargetPath) || FPaths::DirectoryExists(TargetPath))
		{
			
			if(const FString TargetDirectoryPath = FPaths::GetPath(TargetPath);
				FPaths::DirectoryExists(TargetDirectoryPath))
			{
				return FWindowsPlatformMisc::OsExecute(TEXT("open"),*TargetDirectoryPath,nullptr);
			}
		}
		else
		{
			return !DeleteMessageDialog(InPath);
		}
	}
	return false;
}

bool FAUtilities::DeleteIconAndShortcut(const TCHAR* InShortcutPath)
{
	if(!FPaths::FileExists(InShortcutPath)) return false;
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	return PlatformFile.DeleteFile(InShortcutPath);
	/*style initial test, if shortcut be ,style will delete icon as well*/
}

bool FAUtilities::RenameIconAndShortcut(const FString& OldName,const FString& NewName)
{
	if(OldName.Equals(NewName)) return false;
	
	const FString OldShortcutPath = FPaths::Combine(GetShortcutsDirectory(),OldName+".lnk");
	const FString OldIconPath = FPaths::Combine(GetIconsDirectory(),OldName+".png");
	FString NewShortcutPath = FPaths::Combine(GetShortcutsDirectory(),NewName+".lnk");
	FString NewIconPath = FPaths::Combine(GetIconsDirectory(),NewName+".png");
	
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

	/*just test file , well folder icon may not exists*/
	if(!PlatformFile.FileExists(*OldShortcutPath)) return false;
	
	/*is icon path not exists , it is folder */
	const bool IsFolder = !PlatformFile.FileExists(*OldIconPath);
	
	/*same name, append int until not as same*/
	int i = 1;
	while (PlatformFile.FileExists(*NewShortcutPath) && i<99)
	{
		NewShortcutPath = FPaths::Combine(GetShortcutsDirectory(),NewName+FString::FromInt(i)+".lnk");
		if(!IsFolder) 
		{
			NewIconPath = FPaths::Combine(GetIconsDirectory(),NewName+FString::FromInt(i)+".png");
		}
		i++;
	}

	bool Process = false;
	/*if while 99 times, there will be true, fail*/
	if(!PlatformFile.FileExists(*NewShortcutPath)) 
	{
		/*move to same folder is rename*/
		PlatformFile.MoveFile(*NewShortcutPath,*OldShortcutPath);
		Process = true;
	}
	/*if while 99 times, there will be true, fail*/
	if(!IsFolder && !PlatformFile.FileExists(*NewIconPath))
	{
		PlatformFile.MoveFile(*NewIconPath,*OldIconPath);
		Process = true;
	}
	return Process;
}

bool FAUtilities::DeleteMessageDialog(const TCHAR* InPath)
{
	FText Title = FText::FromString(TEXT("Warning"));
	FText Message = FText::FromString(TEXT("The target does not exist on the disk. Do you want to delete the item?"));
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 2
	if(FMessageDialog::Open(EAppMsgType::OkCancel,Message,&Title) == EAppReturnType::Ok)
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION > 2
	if(FMessageDialog::Open(EAppMsgType::YesNo,Message,Title) == EAppReturnType::Yes)
#endif
	{
		DeleteIconAndShortcut(InPath);
		return true;
	}
	return false;
}

bool FAUtilities::OpenSelectFileDialog(TArray<FString>& OutFilenames)
{
	SetIsOpenedDialogPresent(true);
	bool bSuccess = false;
	//CoInitialize(NULL);
	if (!FWindowsPlatformMisc::CoInitialize()){return bSuccess;}
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };
  
	TComPtr<IFileDialog> FileDialog;  
	
	if (SUCCEEDED(::CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER,IID_IFileOpenDialog, IID_PPV_ARGS_Helper(&FileDialog))))
	{
		// Set this up as a multi-select picker
		DWORD DwFlags = 0;
		ensure(SUCCEEDED(FileDialog->GetOptions(&DwFlags)));
		ensure(SUCCEEDED(FileDialog->SetOptions(DwFlags | FOS_ALLOWMULTISELECT)));
		
		//Set dialog's title
		const FString DialogTitle = TEXT("Choose files...");
		ensure(SUCCEEDED(FileDialog->SetTitle(*DialogTitle)));

		//set default path, if not, show last time
		/*if (!DefaultPath.IsEmpty())
		{
			// SHCreateItemFromParsingName requires the given path be absolute and use \ rather than / as our normalized paths do
			FString DefaultWindowsPath = FPaths::ConvertRelativePathToFull(DefaultPath);
			DefaultWindowsPath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);

			TComPtr<IShellItem> DefaultPathItem;
			if (SUCCEEDED(::SHCreateItemFromParsingName(*DefaultWindowsPath, nullptr, IID_PPV_ARGS(&DefaultPathItem))))
			{
				FileDialog->SetFolder(DefaultPathItem);
			}
		}*/
		
		// Set-up the file type filters
		const FString FileTypes = TEXT("All Files (*.*)|*.*|Image Files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|Document Files (*.doc;*.docx;*.pdf;*.txt)|*.doc;*.docx;*.pdf;*.txt");
		TArray<FString> UnformattedExtensions;
		TArray<COMDLG_FILTERSPEC> FileDialogFilters;
		{
			// Split the given filter string (formatted as "Pair1String1|Pair1String2|Pair2String1|Pair2String2") into the Windows specific filter struct
			FileTypes.ParseIntoArray(UnformattedExtensions, TEXT("|"), true);

			if (UnformattedExtensions.Num() % 2 == 0)
			{
				FileDialogFilters.Reserve(UnformattedExtensions.Num() / 2);
				for (int32 ExtensionIndex = 0; ExtensionIndex < UnformattedExtensions.Num();)
				{
					COMDLG_FILTERSPEC& NewFilterSpec = FileDialogFilters[FileDialogFilters.AddDefaulted()];
					NewFilterSpec.pszName = *UnformattedExtensions[ExtensionIndex++];
					NewFilterSpec.pszSpec = *UnformattedExtensions[ExtensionIndex++];
				}
			}
		}
		ensure(SUCCEEDED(FileDialog->SetFileTypes(FileDialogFilters.Num(), FileDialogFilters.GetData())));

		//show windows
		if (SUCCEEDED(FileDialog->Show(NULL)))
		{
			auto AddOutFilename = [&OutFilenames](const FString& InFilename)
			{
				FString& OutFilename = OutFilenames[OutFilenames.Add(InFilename)];
				//OutFilename = IFileManager::Get().ConvertToRelativePath(*OutFilename);
				FPaths::NormalizeFilename(OutFilename);
			};
			
			IFileOpenDialog* FileOpenDialog = static_cast<IFileOpenDialog*>(FileDialog.Get());
			TComPtr<IShellItemArray> Results;
			if (SUCCEEDED(FileOpenDialog->GetResults(&Results)))
			{
				DWORD NumResults = 0;
				ensure(SUCCEEDED(Results->GetCount(&NumResults)));
				for (DWORD ResultIndex = 0; ResultIndex < NumResults; ++ResultIndex)
				{
					TComPtr<IShellItem> Result;
					if (SUCCEEDED(Results->GetItemAt(ResultIndex, &Result)))
					{
						PWSTR PFilePath = nullptr;
						if (SUCCEEDED(Result->GetDisplayName(SIGDN_FILESYSPATH, &PFilePath)))
						{
							bSuccess = true;
							AddOutFilename(PFilePath);
							::CoTaskMemFree(PFilePath); //release memory
						}
					}
				}
			}
		}
	}  
  
	CoUninitialize();
	SetIsOpenedDialogPresent(false);
	return bSuccess;
}

bool FAUtilities::OpenSelectFolderDialog(FString& OutFolderName)
{
	SetIsOpenedDialogPresent(true);
	
	bool bSuccess = false;
	//CoInitialize(NULL);
	if (!FWindowsPlatformMisc::CoInitialize()){return bSuccess;}
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };

	TComPtr<IFileOpenDialog> FileDialog;
	if (SUCCEEDED(::CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&FileDialog))))
	{
		// Set this up as a folder picker
		{
			DWORD DwFlags = 0;
			ensure(SUCCEEDED(FileDialog->GetOptions(&DwFlags)));
			ensure(SUCCEEDED(FileDialog->SetOptions(DwFlags | FOS_PICKFOLDERS)));
		}

		//Set dialog's title
		const FString DialogTitle = TEXT("Choose a folder...");
		ensure(SUCCEEDED(FileDialog->SetTitle(*DialogTitle)));
		
		// Show the picker
		if (SUCCEEDED(FileDialog->Show(NULL)))
		{
			TComPtr<IShellItem> Result;
			if (SUCCEEDED(FileDialog->GetResult(&Result)))
			{
				PWSTR PFilePath = nullptr;
				if (SUCCEEDED(Result->GetDisplayName(SIGDN_FILESYSPATH, &PFilePath)))
				{
					bSuccess = true;

					OutFolderName = PFilePath;
					FPaths::NormalizeDirectoryName(OutFolderName);
					OutFolderName.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
					
					::CoTaskMemFree(PFilePath);
				}
			}
		}
	}

	CoUninitialize();
	SetIsOpenedDialogPresent(false);
	return bSuccess;
}

bool FAUtilities::GetIsOpenedDialogPresent()
{
	return FAUtilitiesProperty::GbOpenedDialogPresent;
}

void FAUtilities::SetIsOpenedDialogPresent(const bool bIsDialogPresent)
{
	FAUtilitiesProperty::GbOpenedDialogPresent = bIsDialogPresent;
}

bool FAUtilities::ExecuteAddNewFile()
{
	bool bProcess = false;
	
	if(TArray<FString> OutFiles;
		OpenSelectFileDialog(OutFiles))
	{
		for(FString CurrentFile : OutFiles)
		{
			/*As long as any one of them succeeds, it is set to true. */
			if(CreateShortcut(*CurrentFile)){bProcess = true;}
			
			if(FPaths::GetExtension(CurrentFile).Equals(TEXT("jpg")) || FPaths::GetExtension(CurrentFile).Equals(TEXT("png")))
			{
				if(CopyTexture(*CurrentFile)){bProcess = true;}
			}
			else
			{
				if(SaveIconToPng(*CurrentFile)){bProcess = true;}
			}
		}
		if(bProcess){FIconStyle::RefreshSet();}
	}
	
	return bProcess;
}

bool FAUtilities::ExecuteAddNewFolder()
{
	if(FString FolderPath;
		OpenSelectFolderDialog(FolderPath))
	{
		return CreateShortcut(*FolderPath);  
	}
	return false;
}

#endif