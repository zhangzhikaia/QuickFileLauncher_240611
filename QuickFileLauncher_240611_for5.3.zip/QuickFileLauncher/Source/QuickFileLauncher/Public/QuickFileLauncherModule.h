// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FQuickFileLauncherModule final : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
private:
	void RegisterToolBarFAMenu();
	
	static void OpenQuickFileLauncherPanel();

	static void RegisterIconPanelTab();
	
public:
	//static bool ExecuteAddNewFile();
	//static bool ExecuteAddNewFolder();
	//static FQuickFileLauncherModule& Get();
	
};
