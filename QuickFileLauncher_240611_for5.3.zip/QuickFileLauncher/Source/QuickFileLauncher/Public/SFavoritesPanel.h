﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "Widgets/Views/STileView.h"

class FFAItem;

class SFavoritesPanel final : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SFavoritesPanel){}
	SLATE_END_ARGS()
public:
	void Construct(const FArguments& InArgs);
	
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	
private:
	
	TSharedRef<STileView<TSharedPtr<FFAItem>>> ConstructTileView();
	
	TSharedRef<ITableRow> OnGenerateTileItem(TSharedPtr<FFAItem> InFAItem,const TSharedRef<STableViewBase>& OwnerTable);

	TSharedPtr<SWidget> HandleQuickFileLauncherContextMenuOpening();

	//TSharedRef<SWidget> MakeContextMenu();

	void RefreshFFAItems();
	void RefreshList();
	
	//FReply HandleDeleteButton();
	
	FReply HandleAddNewFileButton();
	FReply HandleAddNewFolderButton();

	void BindCommands();

	bool HandleRenameCommandCanExecute() const;
	/** Handler for Rename */
	void HandleRenameCommand() const;

	bool HandleDeleteCommandCanExecute() const;
	void HandleDeleteCommand();
	
	bool HandleSelectAllCommandCanExecute() const;
	void HandleSelectAllCommand();

	/** An asset item has started to be renamed */
	void AssetRenameBegin(const TSharedPtr<FFAItem>& Item, const FString& LastName);
	/** An asset item that was prompting the user for a new name was committed. Return false to indicate that the user should enter a new name */
	void AssetRenameCommit(const TSharedPtr<FFAItem>& Item, const FString& NewName, const ETextCommit::Type CommitType);


	TSharedPtr<STileView<TSharedPtr<FFAItem>>> ConstructedTileView;

	/** Commands handled by this widget */
	TSharedPtr< FUICommandList > QuickFileLauncherCommands;
	
	/** The items that are being shown in the filtered view list */
	TArray<TSharedPtr<FFAItem>> FFAItems;

	FString ItemName;
	
};

