// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
//#include <windows.h>
typedef HICON__* HICON;
typedef _GUID CLSID;

#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message);
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%i"),message);
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message.ToString());
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
		UE_LOG(LogTemp,Warning,TEXT("FastPring : Debug"));
	}
}
#endif

namespace FAUtilities
{
	FString GetQuickFileLauncherName();

	FString GetQuickFileLauncherFolderPath();
	
	FString GetIconsDirectory();

	FString GetShortcutsDirectory();

	bool CreateShortcut(const TCHAR* InFilePath);

	FString GetShortcutTargetPath(const TCHAR* InFilePath);
	
	bool ExtractHIcon(const TCHAR* InFilePath,HICON& InHIcon);

	bool GetEncoderClsid(const TCHAR* Format, CLSID* PClsid);

	bool SaveIconToPng(const TCHAR* InFilePath);

	bool CopyTexture(const TCHAR* InFilePath);

	bool OpenFileOrFolder(const TCHAR* InPath);

	bool OpenDirectory(const TCHAR* InPath);

	bool DeleteIconAndShortcut(const TCHAR* InShortcutPath);

	bool RenameIconAndShortcut(const FString& OldName,const FString& NewName);

	bool DeleteMessageDialog(const TCHAR* InPath);

	bool OpenSelectFileDialog(TArray<FString>& OutFilenames);

	bool OpenSelectFolderDialog(FString& OutFolderName);

	bool GetIsOpenedDialogPresent();

	void SetIsOpenedDialogPresent(const bool bIsDialogPresent);

	bool ExecuteAddNewFile();
	
	bool ExecuteAddNewFolder();

}